package com.example.springwebproject1.service;

import java.util.List;

import com.example.springwebproject1.model.Sector;

public interface SectorService {
	
	public List<Sector> getSectorList();

}
