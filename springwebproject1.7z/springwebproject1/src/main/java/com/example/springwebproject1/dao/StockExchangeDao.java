package com.example.springwebproject1.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springwebproject1.model.StockExchange;


public interface StockExchangeDao extends JpaRepository<StockExchange , Integer>{

}
