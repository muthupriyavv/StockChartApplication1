package com.example.springwebproject1.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.springwebproject1.model.Company;
import com.example.springwebproject1.model.IPO_planned;
import com.example.springwebproject1.service.CompanyService;
import com.example.springwebproject1.service.IPOService;
import com.example.springwebproject1.service.StockExchangeService;

@Controller
public class IPOController {
	
	@Autowired
	IPOService iposervice;
	
	@Autowired 
	CompanyService companyservice;
	
	@Autowired
	StockExchangeService stockexchangeservice;
	
	 
	   @RequestMapping(path="/displayipo")
		public ModelAndView getStockList() throws Exception {
			ModelAndView mv=new ModelAndView();
			mv.setViewName("DisplayIPO");
			mv.addObject("ipoList",iposervice.getIPOList());
			return mv;
		}
	
	   @RequestMapping(path="/addipo" , method = RequestMethod.GET)
	    public ModelAndView registerIpo(Model model) throws SQLException, ClassNotFoundException {
	           System.out.println("Inside Add Ipo");
	           ModelAndView mv = new ModelAndView();
	           mv.setViewName("AddIpo");
	           ArrayList companyDetails =(ArrayList) companyservice.getCompanyList();
	           mv.addObject("companyList",companyDetails);
	           ArrayList stockexchangedetails = (ArrayList) stockexchangeservice.getStockList();
	           mv.addObject("stockexchangeList",stockexchangedetails);
	           model.addAttribute("ipo",new IPO_planned());
	           return mv;

	    }  
	   
	   
	   @RequestMapping(value = "/addipo", method = RequestMethod.POST)
	    public ModelAndView registerAdmin(@ModelAttribute("ipo") IPO_planned ipo_planned, BindingResult result,
	               HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException, ClassNotFoundException {
	         ModelAndView mav = null;
	         map.addAttribute("ipo", ipo_planned);
	         iposervice.insertIPO(ipo_planned);
	         ArrayList companyDetails =(ArrayList) companyservice.getCompanyList();
	         ArrayList stockexchangedetails = (ArrayList) stockexchangeservice.getStockList();
	         mav = new ModelAndView("DisplayIPO");
	         mav.addObject("companyList",companyDetails);
	         mav.addObject("stockexchangeList",stockexchangedetails);
	         mav.addObject("ipoList", iposervice.getIPOList());
	         return mav;

	    }
	   
	   
	   @RequestMapping("/ipoUpdate")
	    public ModelAndView companyUpdation(@RequestParam("id") int ipoId, ModelMap map, HttpServletRequest request,
	                  @ModelAttribute("ipo") IPO_planned ipoplanned,HttpSession session) throws ClassNotFoundException, SQLException {
	                        ModelAndView mav = null;
	                        ipoplanned = iposervice.fetchIpoUpdate(ipoId);
	                        ArrayList companyDetails =(ArrayList) companyservice.getCompanyList();
	                        map.addAttribute("companyList",companyDetails);
	                        ArrayList stockexchangedetails = (ArrayList) stockexchangeservice.getStockList();
	                        map.addAttribute("stockexchangeList",stockexchangedetails);
	                        map.addAttribute("update", ipoplanned);
	                        mav = new ModelAndView("CompanyUpdate");
	                        return mav;
	           
	    }
	
	
           
           
}
