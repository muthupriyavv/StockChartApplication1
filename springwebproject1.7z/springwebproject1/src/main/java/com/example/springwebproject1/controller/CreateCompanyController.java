package com.example.springwebproject1.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.springwebproject1.model.Company;
import com.example.springwebproject1.service.CompanyService;
import com.example.springwebproject1.service.SectorService;

@Controller
public class CreateCompanyController {
	
	@Autowired
	private CompanyService companyservice;
	
	@Autowired 
	private SectorService sectorservice;
	
	   @RequestMapping(value = "/index", method = RequestMethod.GET)
	   public String index() {
		   return "index";
	   }
	   
	/*   @RequestMapping(value = "/AdminLogin", method = RequestMethod.GET)
	   public String AdminLogin() {
		   return "AdminLogin";
	   }*/
	   
	  /* @RequestMapping(value = "/AdminLandingPage", method = RequestMethod.GET)
	   public String AdminLandingPage() {
		   return "AdminLandingPage";
	   }*/
	   
	   /*@RequestMapping(value = "/Admin_registration_page", method = RequestMethod.GET)
	   public String Admin_registration_page() {
		   return "Admin_registration_page";
	   }*/
	   
	   
	   
	
	
	@RequestMapping(value = "/registerCompany", method = RequestMethod.POST)
    public ModelAndView registerAdmin(@ModelAttribute("createcompany") Company company, BindingResult result,
               HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException, ClassNotFoundException {
          ModelAndView mav = null;
         map.addAttribute("createcompany", company);
         companyservice.insertCompany(company);  
         System.out.println("kjojnojn");
         ArrayList sectorDetails =(ArrayList) sectorservice.getSectorList();
         mav = new ModelAndView("companyList");
         mav.addObject("sectorList",sectorDetails);
         mav.addObject("companyList", companyservice.getCompanyList());
         return mav;

    }

    @RequestMapping(path = "/company", method = RequestMethod.GET)
    public ModelAndView registerCompany(Model model) throws Exception {
    	 System.out.println("kjojnojn");
          ModelAndView mv = new ModelAndView();
          mv.setViewName("CreateCompany");
          ArrayList sectorDetails =(ArrayList) sectorservice.getSectorList();
          mv.addObject("sectorList",sectorDetails);
          model.addAttribute("createcompany",new Company());
          return mv;
    }    
    
    
    @RequestMapping("/companyUpdate")
    public ModelAndView companyUpdation(@RequestParam("id") int companyId, ModelMap map, HttpServletRequest request,
                  @ModelAttribute("company") Company company,HttpSession session) throws ClassNotFoundException, SQLException {
                        ModelAndView mav = null;
                        company = companyservice.fetchStockUpdate(companyId);
                        ArrayList sectorDetails =(ArrayList) sectorservice.getSectorList();
                        map.addAttribute("sectorList",sectorDetails);
                        map.addAttribute("update", company);
                        mav = new ModelAndView("CompanyUpdate");
                        return mav;
           
    }

    

    @RequestMapping(value = "/updateCompany", method = RequestMethod.POST)
           public ModelAndView updateCompany(HttpServletRequest request, ModelMap map, HttpSession session,
                  @ModelAttribute("company") Company company, BindingResult result) throws ClassNotFoundException, SQLException
                         {
           
                  ModelAndView mav = null;
                         ArrayList companyDetails = null;
                         int companyId = company.getCompany_code();
                         if (result.hasErrors()) {
                               Company company1 = new Company();
                               company1= companyservice.fetchStockUpdate(companyId);
                               map.addAttribute("update", company1);
                               mav = new ModelAndView("CompanyUpdate");
                               return mav;
                         }
                         companyservice.updateCompany(company);
                         System.out.println(company.getCompany_name());
                         companyDetails = (ArrayList) companyservice.getCompanyList();
                         map.addAttribute("companyList", companyDetails);
                         mav = new ModelAndView("companyList");
                         return mav;
                  
           }
    
    
    


   

}
