package com.example.springwebproject1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springwebproject1.dao.IPODao;
import com.example.springwebproject1.model.IPO_planned;

@Service
public class IPOServiceImpl implements IPOService {

	
	@Autowired
	IPODao ipodao;
	@Override
	public IPO_planned insertIPO(IPO_planned ipo_planned) {
		// TODO Auto-generated method stub
		ipodao.save(ipo_planned);
		return ipo_planned;
	}

	@Override
	public List<IPO_planned> getIPOList() {
		// TODO Auto-generated method stub
		return ipodao.findAll();
	}

	@Override
	public IPO_planned fetchIpoUpdate(int ipoId) {
		// TODO Auto-generated method stub
		return ipodao.getOne(ipoId);
	}

}
