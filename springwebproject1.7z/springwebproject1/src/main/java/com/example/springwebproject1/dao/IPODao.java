package com.example.springwebproject1.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springwebproject1.model.IPO_planned;



public interface IPODao extends JpaRepository<IPO_planned, Integer> {
	//public IPO_planned findByCompanyCode(int companyCode) ;
}