package com.example.springwebproject1.service;

import java.util.List;


import com.example.springwebproject1.model.IPO_planned;

public interface IPOService {
	
	public IPO_planned insertIPO(IPO_planned ipo_planned);
	public List<IPO_planned> getIPOList();
	public IPO_planned fetchIpoUpdate(int ipoId);

}
