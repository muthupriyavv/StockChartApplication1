package com.example.springwebproject1.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.springwebproject1.model.StockExchange;
import com.example.springwebproject1.service.StockExchangeService;

@Controller
public class StockExchangeController {
	
	   @Autowired
	   StockExchangeService stockexchangeservice;
	   
	   @RequestMapping(path="/stockexchangelist")
		public ModelAndView getStockList() throws Exception {
			ModelAndView mv=new ModelAndView();
			mv.setViewName("StockExchangeList");
			mv.addObject("stockExchangeList",stockexchangeservice.getStockList());
			return mv;
		}
		

	   @RequestMapping(path="/newstockexchange" , method = RequestMethod.GET)
	    public ModelAndView registerStockExchange(ModelMap map) throws SQLException {
	           ModelAndView mav = null;
	           System.out.println("Inside Stock Exchange");
	           map.addAttribute("stockex", new StockExchange());
	           mav = new ModelAndView("StockExchangeRegister");
	           return mav;

	    }  
	   
	   
	   @RequestMapping(path="/newstockexchange" , method = RequestMethod.POST)
	   public ModelAndView registeredStock(@ModelAttribute("stockex") StockExchange stockexchange, BindingResult result,
               HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException, ClassNotFoundException {
		       
		       ModelAndView mav = null;
		       map.addAttribute("stockex", stockexchange);
		       stockexchangeservice.insertStock(stockexchange);
		       mav = new ModelAndView("StockExchangeList");
		       mav.addObject("stockExchangeList", stockexchangeservice.getStockList());
		       return mav;
		   
	   }
}
