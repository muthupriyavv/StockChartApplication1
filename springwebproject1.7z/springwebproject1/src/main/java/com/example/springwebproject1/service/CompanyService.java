package com.example.springwebproject1.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.springwebproject1.model.Company;


public interface CompanyService {

	
	  public Company insertCompany(Company company) throws SQLException;
	    public void updateCompany(Company company);
		public List<Company> getCompanyList() throws SQLException, ClassNotFoundException;
		public Company fetchStockUpdate(int companyId) throws SQLException, ClassNotFoundException ;

}
